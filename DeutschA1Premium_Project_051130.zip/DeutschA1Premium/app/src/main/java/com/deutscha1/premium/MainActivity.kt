
package com.deutscha1.premium

import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.app.Activity
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private var hearts = 5
    private var xp = 0
    private var ttsReady = false
    private lateinit var content: LinearLayout
    private lateinit var heartsText: TextView
    private val bg = Color.rgb(10, 12, 20)
    private val card = Color.rgb(22, 25, 36)
    private val accent = Color.rgb(116, 91, 255)
    private val gold = Color.rgb(230, 183, 72)
    private val white = Color.WHITE
    private val muted = Color.rgb(168, 172, 190)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        showHome()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale.GERMAN)
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
            tts.setSpeechRate(0.88f)
            tts.setPitch(1.0f)
        }
    }

    private fun speak(text: String) {
        if (ttsReady) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "a1_" + System.nanoTime())
    }

    private fun base(): LinearLayout {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(bg)
        root.setPadding(dp(18), dp(18), dp(18), dp(14))
        return root
    }

    private fun header(title: String, subtitle: String? = null): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, dp(8), 0, dp(14))
        val t = tv(title, 28, white)
        t.typeface = android.graphics.Typeface.DEFAULT_BOLD
        box.addView(t)
        subtitle?.let { box.addView(tv(it, 14, muted)) }
        return box
    }

    private fun topBar(): LinearLayout {
        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        val logo = tv("DEUTSCH A1", 20, white)
        logo.typeface = android.graphics.Typeface.DEFAULT_BOLD
        bar.addView(logo, LinearLayout.LayoutParams(0, dp(42), 1f))
        heartsText = tv("♥ $hearts", 16, Color.rgb(255, 92, 118))
        bar.addView(heartsText)
        return bar
    }

    private fun tv(text: String, size: Int, color: Int): TextView {
        val v = TextView(this)
        v.text = text
        v.textSize = size.toFloat()
        v.setTextColor(color)
        v.gravity = Gravity.CENTER_VERTICAL
        return v
    }

    private fun cardButton(title: String, subtitle: String, icon: String, action: () -> Unit): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(18), dp(16), dp(18), dp(16))
        c.setBackgroundColor(card)
        c.isClickable = true
        c.setOnClickListener { action() }
        val line = LinearLayout(this)
        line.gravity = Gravity.CENTER_VERTICAL
        val i = tv(icon, 28, gold)
        line.addView(i, LinearLayout.LayoutParams(dp(48), dp(48)))
        val texts = LinearLayout(this)
        texts.orientation = LinearLayout.VERTICAL
        texts.addView(tv(title, 19, white))
        texts.addView(tv(subtitle, 13, muted))
        line.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        c.addView(line)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, 0, 0, dp(12))
        c.layoutParams = lp
        return c
    }

    private fun showHome() {
        val root = base()
        root.addView(topBar())
        root.addView(header("طريقك إلى A1", "تعلّم، طبّق، وتقدّم خطوة بخطوة"))
        val scroll = ScrollView(this)
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.addView(progressCard())
        content.addView(cardButton("الكلمات", "800 كلمة ألمانية • نطق فوري • مراجعة ذكية", "A", ::showWords))
        content.addView(cardButton("القواعد", "تعلّم القاعدة من خلال التمرين، بدون شرح طويل", "G", ::showGrammar))
        content.addView(cardButton("Hören — الهوجن", "10 نصوص • 5 قراءة + 5 استماع", "H", ::showListening))
        content.addView(cardButton("Schreiben — الكتابة", "أسئلة مقابلة A1 وأجوبة تكتبها بنفسك", "S", ::showWriting))
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun progressCard(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(18), dp(16), dp(18), dp(16))
        c.setBackgroundColor(Color.rgb(30, 29, 48))
        c.addView(tv("المستوى A1", 15, gold))
        c.addView(tv("$xp XP", 24, white))
        val p = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        p.max = 100
        p.progress = (xp.coerceAtMost(100))
        c.addView(p, LinearLayout.LayoutParams(-1, dp(8)))
        return c
    }

    private fun titleScreen(title: String, sub: String): LinearLayout {
        val root = base()
        val back = Button(this)
        back.text = "‹ رجوع"
        back.setTextColor(white)
        back.setBackgroundColor(Color.TRANSPARENT)
        back.setOnClickListener { showHome() }
        root.addView(back, LinearLayout.LayoutParams(-1, dp(44)))
        root.addView(header(title, sub))
        return root
    }

    private fun showWords() {
        val root = titleScreen("الكلمات", "800 مفردة بدون تكرار • اضغط على 🔊 لسماع النطق فورًا")
        val scroll = ScrollView(this)
        val list = LinearLayout(this); list.orientation = LinearLayout.VERTICAL
        val data = loadWords()
        data.take(120).forEach { e ->
            val row = LinearLayout(this); row.setPadding(dp(14),dp(10),dp(8),dp(10)); row.setBackgroundColor(card)
            val text = LinearLayout(this); text.orientation = LinearLayout.VERTICAL
            text.addView(tv(e.word,18,white))
            text.addView(tv(e.meaning,13,muted))
            row.addView(text, LinearLayout.LayoutParams(0,-2,1f))
            val b = Button(this); b.text="🔊"; b.setOnClickListener { speak(e.tts) }
            row.addView(b, LinearLayout.LayoutParams(dp(58),dp(52)))
            val lp=LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,dp(5)); row.layoutParams=lp
            list.addView(row)
        }
        scroll.addView(list); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
    }

    private fun showGrammar() {
        val root = titleScreen("القواعد", "ما في شرح مطوّل — القاعدة تنبني من التمرين")
        val scroll=ScrollView(this); val list=LinearLayout(this); list.orientation=LinearLayout.VERTICAL
        val drills = listOf(
            "Ich ___ in Berlin.  → lebe / lebt / leben" to "lebe",
            "Du ___ heute Deutsch. → lernst / lernen / lernt" to "lernst",
            "Er ___ einen Kaffee. → trinkt / trinken / trinkst" to "trinkt",
            "Wir ___ morgen nach Hause. → fahren / fährt / fährst" to "fahren",
            "Sie ___ sehr nett. → ist / sind / bist" to "ist",
            "Ich habe ___ Bruder. → ein / einen / eine" to "einen",
            "Das ist ___ Mutter. → mein / meine / meinen" to "meine",
            "Ich gehe ___ Schule. → zur / zum / der" to "zur"
        )
        drills.forEachIndexed { idx, pair ->
            val c=LinearLayout(this); c.orientation=LinearLayout.VERTICAL; c.setPadding(dp(16),dp(14),dp(16),dp(14)); c.setBackgroundColor(card)
            c.addView(tv("تمرين ${idx+1}",14,gold)); c.addView(tv(pair.first,18,white))
            val input=EditText(this); input.hint="اكتب الإجابة"; input.setTextColor(white); input.setHintTextColor(muted)
            c.addView(input)
            val check=Button(this); check.text="تحقق"; check.setOnClickListener {
                if(input.text.toString().trim().equals(pair.second,true)){ xp+=5; Toast.makeText(this,"✓ صحيح",Toast.LENGTH_SHORT).show() }
                else loseHeart()
            }; c.addView(check)
            val lp=LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,dp(10)); c.layoutParams=lp; list.addView(c)
        }
        scroll.addView(list); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f)); setContentView(root)
    }

    private fun showListening() {
        val root=titleScreen("Hören — الهوجن","10 تدريبات: 5 نصوص مكتوبة + 5 صوتية")
        val scroll=ScrollView(this); val list=LinearLayout(this); list.orientation=LinearLayout.VERTICAL
        val written = listOf(
            "Anna wohnt in Berlin. Sie arbeitet in einem Café. Am Samstag besucht sie ihre Freundin.",
            "Tom hat einen kleinen Hund. Jeden Morgen geht er mit dem Hund im Park spazieren.",
            "Maria lernt Deutsch. Sie hat am Montag einen Deutschkurs und am Freitag eine Prüfung.",
            "Paul fährt mit dem Zug nach Hamburg. Er bleibt dort drei Tage.",
            "Lena kauft im Supermarkt Brot, Milch, Käse und Äpfel."
        )
        val audio = listOf(
            "Guten Morgen! Ich heiße Anna und komme aus Deutschland. Heute gehe ich zur Arbeit.",
            "Hallo! Mein Termin ist um zehn Uhr. Danach möchte ich einen Kaffee trinken.",
            "Ich wohne in einer kleinen Wohnung. Meine Wohnung hat zwei Zimmer.",
            "Am Wochenende fahre ich mit meiner Familie ans Meer. Wir bleiben zwei Tage.",
            "Der Zug kommt um acht Uhr. Bitte warten Sie am Bahnsteig drei."
        )
        written.forEachIndexed { i,text ->
            list.addView(readingCard("نص ${i+1} — قراءة",text,i))
        }
        audio.forEachIndexed { i,text ->
            list.addView(audioCard("استماع ${i+1} — صوت فقط",text,i+5))
        }
        scroll.addView(list); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f)); setContentView(root)
    }

    private fun readingCard(title:String, text:String, seed:Int): View {
        val c=LinearLayout(this); c.orientation=LinearLayout.VERTICAL; c.setPadding(dp(16),dp(15),dp(16),dp(15)); c.setBackgroundColor(card)
        c.addView(tv(title,16,gold)); c.addView(tv(text,18,white))
        val play=Button(this); play.text="🔊 قراءة النص"; play.setOnClickListener { speak(text) }; c.addView(play)
        c.addView(tv("ما الفكرة الأساسية للنص؟",15,muted))
        val opts=listOf("عن العمل والحياة اليومية","عن السفر بالطائرة","عن الرياضة")
        opts.forEachIndexed { j,o ->
            val b=Button(this); b.text=o; b.setOnClickListener { if(j==0){xp+=8;Toast.makeText(this,"✓ صحيح",Toast.LENGTH_SHORT).show()}else loseHeart() }; c.addView(b)
        }
        val lp=LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(12));c.layoutParams=lp;return c
    }

    private fun audioCard(title:String, text:String, seed:Int): View {
        val c=LinearLayout(this); c.orientation=LinearLayout.VERTICAL; c.setPadding(dp(16),dp(15),dp(16),dp(15)); c.setBackgroundColor(card)
        c.addView(tv(title,16,gold)); c.addView(tv("النص غير ظاهر — استمع ثم أجب",15,muted))
        val play=Button(this); play.text="▶ تشغيل الصوت"; play.setOnClickListener { speak(text) }; c.addView(play)
        c.addView(tv("بعد الاستماع: أين/متى/ماذا؟ اختر الإجابة الأقرب.",15,muted))
        listOf("الخيار الأول","الخيار الثاني","الخيار الثالث").forEachIndexed { j,o ->
            val b=Button(this);b.text=o;b.setOnClickListener{if(j==0){xp+=8;Toast.makeText(this,"✓ ممتاز",Toast.LENGTH_SHORT).show()}else loseHeart()};c.addView(b)
        }
        val lp=LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(12));c.layoutParams=lp;return c
    }

    private fun showWriting() {
        val root=titleScreen("Schreiben — الكتابة","أسئلة مقابلة A1 بأسلوب عملي قريب من مهام Sprechen/Schreiben")
        val scroll=ScrollView(this); val list=LinearLayout(this); list.orientation=LinearLayout.VERTICAL
        val qs=listOf("Wie heißt du?","Woher kommst du?","Wo wohnst du?","Was machst du beruflich?","Was machst du gern in deiner Freizeit?",
            "Wie alt bist du?","Was machst du am Wochenende?","Warum lernst du Deutsch?","Was isst du gern?","Wie sieht dein Tag aus?")
        qs.forEachIndexed { i,q ->
            val c=LinearLayout(this);c.orientation=LinearLayout.VERTICAL;c.setPadding(dp(16),dp(14),dp(16),dp(14));c.setBackgroundColor(card)
            c.addView(tv("Frage ${i+1}",14,gold));c.addView(tv(q,20,white))
            val e=EditText(this);e.hint="اكتب جوابك بالألمانية…";e.setTextColor(white);e.setHintTextColor(muted);e.minLines=2;c.addView(e)
            val b=Button(this);b.text="تحقق";b.setOnClickListener{
                if(e.text.toString().trim().split(" ").size>=2){xp+=10;Toast.makeText(this,"✓ إجابة مقبولة — أحسنت",Toast.LENGTH_SHORT).show()}
                else loseHeart()
            };c.addView(b)
            val lp=LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(10));c.layoutParams=lp;list.addView(c)
        }
        scroll.addView(list);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));setContentView(root)
    }

    private fun loseHeart(){
        hearts=(hearts-1).coerceAtLeast(0); heartsText.text="♥ $hearts"
        if(hearts==0) Toast.makeText(this,"انتهت القلوب. خذ استراحة ثم أكمل.",Toast.LENGTH_LONG).show()
        else Toast.makeText(this,"حاول مرة ثانية — تبقى $hearts قلوب",Toast.LENGTH_SHORT).show()
    }

    private data class Word(val word:String,val meaning:String,val tts:String)

    private fun loadWords(): List<Word> {
        val raw = assets.open("words.json").bufferedReader().readText()
        val arr = org.json.JSONArray(raw)
        val out=ArrayList<Word>()
        for(i in 0 until arr.length()){
            val o=arr.getJSONObject(i);out.add(Word(o.getString("word"),o.getString("meaning"),o.getString("tts")))
        }
        return out
    }

    private fun dp(v:Int)= (v*resources.displayMetrics.density).roundToInt()

    override fun onDestroy(){ if(::tts.isInitialized){tts.stop();tts.shutdown()};super.onDestroy() }
}
